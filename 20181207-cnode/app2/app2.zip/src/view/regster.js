import React,{Component} from "react";
export default class Regster extends Component{
    render(){
        return "注册"
    }
}